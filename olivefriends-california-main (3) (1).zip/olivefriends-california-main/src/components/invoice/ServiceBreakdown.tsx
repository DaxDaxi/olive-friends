
import React from 'react';

interface ServiceBreakdownProps {
  description: string;
  amount: string;
  oliveTreesIncluded: string;
}

const ServiceBreakdown = ({ description, amount, oliveTreesIncluded }: ServiceBreakdownProps) => {
  return (
    <div className="border rounded-lg p-6 mb-8">
      <h3 className="font-semibold text-lg mb-4">Service Breakdown</h3>
      <div className="space-y-3">
        <div className="flex justify-between items-center py-2 border-b">
          <span>{description}</span>
          <span className="font-semibold">{amount}</span>
        </div>
        <div className="flex justify-between items-center py-2 text-green-600">
          <span>✓ {oliveTreesIncluded}</span>
          <span className="font-semibold">Included</span>
        </div>
        <div className="flex justify-between items-center py-2 border-t font-bold text-lg">
          <span>Total Paid</span>
          <span>{amount}</span>
        </div>
      </div>
    </div>
  );
};

export default ServiceBreakdown;
