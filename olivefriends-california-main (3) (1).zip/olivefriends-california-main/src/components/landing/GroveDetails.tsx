
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Trees, MapPin, User, Phone, Mail, Building2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

interface Grove {
  id: string;
  name: string;
  description: string | null;
  tree_count: number;
  estimated_harvest: string | null;
  latitude: number;
  longitude: number;
  picture_urls: string[] | null;
  owner_id: string;
}

interface GroveDetailsProps {
  grove: Grove;
  children: React.ReactNode;
}

const GroveDetails = ({ grove, children }: GroveDetailsProps) => {
  const { user } = useAuth();
  const { t } = useLanguage();

  // Mock owner data since we removed Supabase
  const mockOwnerProfile = {
    full_name: 'Grove Owner',
    company_name: 'Example Grove Company',
    phone_number: '+1-555-0123',
    address: '123 Grove Street, California, USA'
  };

  const mockOwnerAuth = {
    email: `grove.owner.${grove.owner_id.slice(0, 8)}@example.com`
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{grove.name}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Grove Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trees className="h-5 w-5" />
                {t('groveDetails.groveInformation')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {grove.description && (
                <div>
                  <h4 className="font-medium mb-2">{t('groveDetails.description')}</h4>
                  <p className="text-muted-foreground">{grove.description}</p>
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Trees className="h-4 w-4 text-primary" />
                  <span className="font-medium">{t('groveDetails.trees')}:</span>
                  <span>{grove.tree_count}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="font-medium">{t('groveDetails.location')}:</span>
                  <span>{grove.latitude.toFixed(4)}, {grove.longitude.toFixed(4)}</span>
                </div>
              </div>
              
              {grove.estimated_harvest && (
                <div>
                  <h4 className="font-medium mb-2">{t('groveDetails.estimatedHarvest')}</h4>
                  <p className="text-primary font-medium">{grove.estimated_harvest}</p>
                </div>
              )}
              
              {grove.picture_urls && grove.picture_urls.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">{t('groveDetails.photos')}</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {grove.picture_urls.map((url, index) => (
                      <img
                        key={index}
                        src={url}
                        alt={`${grove.name} photo ${index + 1}`}
                        className="w-full h-24 object-cover rounded-md"
                      />
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Owner Contact Information - Only for logged in renters */}
          {user ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  {t('groveDetails.ownerContact')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockOwnerProfile.full_name && (
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-primary" />
                      <span className="font-medium">{t('groveDetails.name')}:</span>
                      <span>{mockOwnerProfile.full_name}</span>
                    </div>
                  )}
                  
                  {mockOwnerAuth?.email && (
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-primary" />
                      <span className="font-medium">{t('contact.email')}:</span>
                      <a href={`mailto:${mockOwnerAuth.email}`} className="text-primary hover:underline">
                        {mockOwnerAuth.email}
                      </a>
                    </div>
                  )}
                  
                  {mockOwnerProfile.phone_number && (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-primary" />
                      <span className="font-medium">{t('groveDetails.phone')}:</span>
                      <a href={`tel:${mockOwnerProfile.phone_number}`} className="text-primary hover:underline">
                        {mockOwnerProfile.phone_number}
                      </a>
                    </div>
                  )}
                  
                  {mockOwnerProfile.company_name && (
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-primary" />
                      <span className="font-medium">{t('groveDetails.company')}:</span>
                      <span>{mockOwnerProfile.company_name}</span>
                    </div>
                  )}
                  
                  {mockOwnerProfile.address && (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-primary" />
                      <span className="font-medium">{t('groveDetails.address')}:</span>
                      <span>{mockOwnerProfile.address}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <User className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">{t('common.loginRequired')}</h3>
                <p className="text-muted-foreground mb-4">
                  {t('common.loginRequiredDescription')}
                </p>
                <Button asChild>
                  <a href="/login">{t('common.login')}</a>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default GroveDetails;
