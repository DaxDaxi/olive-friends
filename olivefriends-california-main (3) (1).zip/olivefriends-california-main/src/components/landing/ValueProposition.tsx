
import React from 'react';
import { Button } from '@/components/ui/button';
import { Leaf, User, Heart } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const ValueProposition = () => {
  const { t } = useLanguage();

  return (
    <section className="py-20 bg-background">
      <div className="container grid lg:grid-cols-2 gap-12 items-center">
        <div id="for-renters" className="bg-card p-8 rounded-lg shadow-lg">
          <Heart className="h-10 w-10 text-accent mb-4" />
          <h2 className="text-3xl font-bold text-primary mb-4">{t('valueProposition.forRenter.title')}</h2>
          <p className="text-lg text-foreground/80 mb-6">{t('valueProposition.forRenter.description')}</p>
          <ul className="space-y-3 mb-8">
            <li className="flex items-start gap-3"><Leaf className="h-5 w-5 text-primary mt-1 flex-shrink-0" /><span>{t('valueProposition.forRenter.feature1')}</span></li>
            <li className="flex items-start gap-3"><Leaf className="h-5 w-5 text-primary mt-1 flex-shrink-0" /><span>{t('valueProposition.forRenter.feature2')}</span></li>
            <li className="flex items-start gap-3"><Leaf className="h-5 w-5 text-primary mt-1 flex-shrink-0" /><span>{t('valueProposition.forRenter.feature3')}</span></li>
          </ul>
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
            <a href="#featured-groves">{t('valueProposition.forRenter.button')}</a>
          </Button>
        </div>
        <div id="for-owners" className="bg-card p-8 rounded-lg shadow-lg">
          <User className="h-10 w-10 text-accent mb-4" />
          <h2 className="text-3xl font-bold text-primary mb-4">{t('valueProposition.forOwner.title')}</h2>
          <p className="text-lg text-foreground/80 mb-6">{t('valueProposition.forOwner.description')}</p>
          <ul className="space-y-3 mb-8">
            <li className="flex items-start gap-3"><Leaf className="h-5 w-5 text-primary mt-1 flex-shrink-0" /><span>{t('valueProposition.forOwner.feature1')}</span></li>
            <li className="flex items-start gap-3"><Leaf className="h-5 w-5 text-primary mt-1 flex-shrink-0" /><span>{t('valueProposition.forOwner.feature2')}</span></li>
            <li className="flex items-start gap-3"><Leaf className="h-5 w-5 text-primary mt-1 flex-shrink-0" /><span>{t('valueProposition.forOwner.feature3')}</span></li>
          </ul>
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
            <a href="mailto:danilo@olive-friends.com">{t('valueProposition.forOwner.button')}</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ValueProposition;
