
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';
import LanguageSelector from '@/components/LanguageSelector';

// Add test link for development
const isDevelopment = window.location.hostname === 'localhost' || window.location.hostname.includes('lovable.app');

const Header = () => {
  const isMobile = useIsMobile();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, loading } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const navLinks = [
    { title: t('nav.howItWorks'), href: "/how-it-works" },
    { title: t('nav.forOwners'), href: "/for-owners" },
    { title: t('nav.forRenters'), href: "/for-renters" },
  ];

  const handleLinkClick = () => {
    setIsMenuOpen(false);
  };

  const handleLogout = async () => {
    handleLinkClick();
    toast.success(t('common.loggedOutSuccessfully'));
    navigate('/');
  };

  const NavMenu = () => (
    <nav className={`flex items-center gap-4 ${isMobile ? 'flex-col absolute top-full left-0 w-full bg-background/95 backdrop-blur-sm p-6 shadow-lg' : 'flex-row'}`}>
      {navLinks.map(link => (
        <Link key={link.title} to={link.href} className="text-foreground/80 hover:text-primary transition-colors text-lg" onClick={handleLinkClick}>
          {link.title}
        </Link>
      ))}
      {isDevelopment && (
        <Link to="/test-functions" className="text-foreground/80 hover:text-primary transition-colors text-lg" onClick={handleLinkClick}>
          {t('nav.tests')}
        </Link>
      )}
      <div className={`flex gap-2 ${isMobile ? 'flex-col w-full mt-4' : 'flex-row items-center ml-4'}`}>
        <LanguageSelector />
        {loading ? (
          <div className="h-10 w-48 bg-muted/50 animate-pulse rounded-md" />
        ) : user ? (
          <Button onClick={handleLogout} variant="outline">
            {t('nav.logOut')}
          </Button>
        ) : null}
      </div>
    </nav>
  );

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container h-20 flex items-center justify-between">
        <Logo />
        {isMobile ? (
          <>
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
            {isMenuOpen && <NavMenu />}
          </>
        ) : (
          <NavMenu />
        )}
      </div>
    </header>
  );
};

export default Header;
