
import React from 'react';

interface InvoiceDetailsProps {
  paymentDate: string;
  validFrom: string;
  validUntil: string;
  description: string;
  amount: string;
  oliveTreesIncluded: string;
}

const InvoiceDetails = ({ 
  paymentDate, 
  validFrom, 
  validUntil, 
  description, 
  amount, 
  oliveTreesIncluded 
}: InvoiceDetailsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
      <div>
        <h3 className="font-semibold text-lg mb-4">Billing Information</h3>
        <div className="space-y-2">
          <p><strong>Payment Date:</strong> {paymentDate}</p>
          <p><strong>Membership Valid From:</strong> {validFrom}</p>
          <p><strong>Membership Valid Until:</strong> {validUntil}</p>
        </div>
      </div>
      
      <div>
        <h3 className="font-semibold text-lg mb-4">Service Details</h3>
        <div className="space-y-2">
          <p><strong>Service:</strong> {description}</p>
          <p><strong>Amount Paid:</strong> {amount}</p>
          <p><strong>Includes:</strong> {oliveTreesIncluded}</p>
        </div>
      </div>
    </div>
  );
};

export default InvoiceDetails;
