
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';

const HowItWorks = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-6">How It Works</h1>
          <div className="space-y-6 text-lg text-foreground/80">
            <p>
              <strong>OliveFriends</strong> offers a unique opportunity to connect with the ancient tradition of olive cultivation. Our platform is designed to be simple and rewarding for both olive tree enthusiasts and grove owners.
            </p>
            <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
              <p className="text-lg text-foreground/80">
                We believe that <strong>Olives</strong> can make you new <strong>Friends</strong> on this platform.
              </p>
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2">1. Choose Your Grove</h2>
              <p>
                Begin your journey by exploring our curated selection of beautiful, family-owned olive groves. Each grove has a unique story, terroir, and variety of olive trees. Read about the owners, their farming practices, and what makes their grove special. We provide detailed profiles to help you find the perfect match.
              </p>
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2">2. Rent Your Tree</h2>
              <p>
                Once you've found a grove you love, you can rent one or more olive trees for a full year. The rental fee helps support the farmer's sustainable practices and contributes to the preservation of these agricultural treasures. As a renter, you're not just a customer; you're a patron of the grove.
              </p>
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2">3. Follow the Journey</h2>
              <p>
                Throughout the year, you'll receive exclusive updates from the grove. See your tree blossom in the spring, watch the olives grow through the summer, and learn about the care it receives from the farmer. Many of our partner groves also welcome visitors, offering you the chance to see your tree in person and even participate in the harvest.
              </p>
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2">4. Enjoy Your Harvest</h2>
              <p>
                The culmination of your year-long journey is the harvest. Depending on your rental agreement, you will receive a share of the olives from your tree or, more commonly, the extra virgin olive oil pressed from them. This isn't just any olive oil; it's *your* olive oil, from *your* tree, with a story you've been a part of. It's delivered right to your doorstep, a delicious reminder of your connection to the land.
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border">
              <h2 className="text-2xl font-bold mb-3 text-primary">Why Full Olive Fruits Matter</h2>
              <p className="mb-3">
                While olive oil is the most famous product from olive trees, the whole fruit offers much more value. After pressing the oil, the remaining olive pulp and pomace can be used to create many wonderful products including olive paste, tapenade, natural cosmetics, and even eco-friendly fertilizers.
              </p>
              <p>
                That's why getting the full fruits from your tree makes perfect sense - you're not just getting oil, you're getting access to nature's complete olive gift. Many of our grove partners offer options to receive whole olives, allowing you to explore the full potential of your tree's harvest.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default HowItWorks;
