
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';

const ForOwners = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">For Grove Owners</h1>
          <div className="space-y-4 text-lg text-foreground/80">
            <p>
              Share your passion, preserve your legacy, and create a sustainable future for your olive grove. OliveFriends connects you with a global community of people who appreciate the hard work and tradition behind every bottle of olive oil.
            </p>
            <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
              <p className="text-lg text-foreground/80">
                You will meet here many nice people and they will become your new <strong>Olive Friends</strong>.
              </p>
            </div>
            <h2 className="text-2xl font-bold pt-4">Why Partner with OliveFriends?</h2>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Stable, Predictable Income:</strong> The tree rental model provides a new and reliable revenue stream, helping you plan for the future regardless of harvest variations.</li>
              <li><strong>Build a Community:</strong> Connect directly with the people who love your products. Share your story, your methods, and your passion with an engaged audience.</li>
              <li><strong>Focus on Farming:</strong> We handle the marketing, logistics, and customer relations, so you can focus on what you do best: cultivating exceptional olives.</li>
              <li><strong>Preserve Your Heritage:</strong> By sharing your grove with the world, you are not just inviting people to be part of your story; you are ensuring your family's legacy continues for generations to come.</li>
            </ul>
            <p>
              Joining is simple and free. We work with you to create a beautiful profile for your grove and help you set up your tree rental offerings.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ForOwners;
