
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';

const ForRenters = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">For Renters</h1>
          <div className="space-y-4 text-lg text-foreground/80">
            <p>
              Experience a connection to your food like never before. When you rent an olive tree through OliveFriends, you're not just buying olive oil; you're becoming part of a story, a tradition, and a community.
            </p>
            <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
              <p className="text-lg text-foreground/80">
                You will meet here many nice people and they will become your new <strong>Olive Friends</strong>.
              </p>
            </div>
            <h2 className="text-2xl font-bold pt-4">What You Get as a Renter:</h2>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>A Personal Connection:</strong> Know your farmer, your grove, and your specific tree. Follow its journey from flower to fruit through regular updates.</li>
              <li><strong>Your Own Harvest:</strong> Receive 100% of your tree's olive oil production, delivered to your door. Taste the unique flavors of its terroir.</li>
              <li><strong>Authenticity & Transparency:</strong> Say goodbye to counterfeit or low-quality oils. You get pure, unadulterated extra virgin olive oil with a clear line of provenance.</li>
              <li><strong>A Unique Experience:</strong> Many groves offer the opportunity to visit, meet the farmers, and even participate in the harvest—a truly unforgettable experience for you and your family.</li>
            </ul>
            <div className="bg-card p-6 rounded-lg border mt-6">
              <h2 className="text-2xl font-bold mb-3 text-primary">Beyond Olive Oil: The Full Fruit Value</h2>
              <p className="mb-3">
                Did you know that olive fruits offer much more than just oil? After the oil is pressed, the remaining olive pulp and pomace can be transformed into numerous valuable products. From delicious olive paste and tapenade to natural cosmetics and eco-friendly fertilizers, the entire fruit has remarkable potential.
              </p>
              <p className="mb-3">
                This is why choosing to receive full fruits from your tree makes perfect sense. You're not limiting yourself to just oil - you're unlocking access to nature's complete olive bounty. Many of our partner groves offer whole olive options, giving you the freedom to explore all the wonderful things you can create from your tree's harvest.
              </p>
              <p>
                Whether you want to make your own olive products, experiment with traditional recipes, or simply enjoy the satisfaction of using every part of your tree's gift, getting the full fruits maximizes the value and experience of your olive tree rental.
              </p>
            </div>
            <p>
              Renting a tree is a perfect gift for foodies, a wonderful family project, or a personal way to enjoy one of nature's most precious gifts.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ForRenters;
