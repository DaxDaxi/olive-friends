
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';

interface PaymentConfirmationBannerProps {
  isVisible: boolean;
}

const PaymentConfirmationBanner = ({ isVisible }: PaymentConfirmationBannerProps) => {
  if (!isVisible) return null;

  return (
    <div className="mb-6 print:hidden">
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-6">
          <div className="flex items-center justify-center text-green-600 mb-4">
            <CheckCircle className="h-8 w-8 mr-3" />
            <h2 className="text-xl font-semibold">Payment Confirmation Issued</h2>
          </div>
          <p className="text-center text-green-700">
            Your payment has been successfully processed and confirmed. Your membership is now active!
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentConfirmationBanner;
