
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Check } from 'lucide-react';

interface MembershipSelectionProps {
  onSkip: () => void;
  onComplete: () => void;
}

const MembershipSelection: React.FC<MembershipSelectionProps> = ({ onSkip, onComplete }) => {
  const membershipPlans = [
    {
      id: 'basic',
      name: 'Basic Membership',
      price: '$99/year',
      features: [
        'Access to basic grove listings',
        'Standard customer support',
        'Basic profile features',
        'Up to 2 tree rentals per year',
      ],
    },
    {
      id: 'premium',
      name: 'Premium Membership',
      price: '$299/year',
      features: [
        'Access to all grove listings',
        'Priority customer support',
        'Advanced profile features',
        'Featured listings for owners',
        'Early access to new groves',
        'Up to 6 tree rentals per year',
        'Harvest updates and photos',
      ],
      popular: true,
    },
    {
      id: 'enterprise',
      name: 'Enterprise Membership',
      price: '$999/year',
      features: [
        'Everything in Premium',
        'Dedicated account manager',
        'Custom grove management tools',
        'API access',
        'Unlimited tree rentals',
        'Bulk tree rental discounts',
        'Personalized adoption certificates',
      ],
    },
  ];

  const handleSubscribe = (membershipType: string) => {
    console.log(`Selected membership: ${membershipType}`);
    onComplete();
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Choose Your Annual Membership</h2>
        <p className="text-muted-foreground">
          Join the OliveFriends community and connect with olive groves worldwide
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {membershipPlans.map((plan) => (
          <Card
            key={plan.id}
            className={`relative ${
              plan.popular ? 'border-primary shadow-lg' : ''
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </span>
              </div>
            )}
            <CardHeader className="text-center">
              <CardTitle className="text-xl">{plan.name}</CardTitle>
              <div className="text-3xl font-bold text-primary">{plan.price}</div>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-3">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <Button
                className="w-full"
                variant={plan.popular ? 'default' : 'outline'}
                onClick={() => handleSubscribe(plan.id)}
              >
                Choose Plan
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center">
        <Button variant="ghost" onClick={onSkip}>
          Skip for now - I'll choose later
        </Button>
        <p className="text-xs text-muted-foreground mt-2">
          Tree rental costs are separate and set by individual grove owners
        </p>
      </div>
    </div>
  );
};

export default MembershipSelection;
