
import React from 'react';
import { Link } from 'react-router-dom';
import { Leaf } from 'lucide-react';

const Logo = () => {
  return (
    <Link to="/" className="flex items-center gap-2">
      <Leaf className="h-7 w-7 text-primary" />
      <span className="text-2xl font-serif font-bold text-primary">
        OliveFriends
      </span>
    </Link>
  );
};

export default Logo;
