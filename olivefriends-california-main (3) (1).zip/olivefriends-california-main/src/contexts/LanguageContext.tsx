
import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'es' | 'it' | 'pt' | 'el' | 'de';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

const translations = {
  en: {
    // Header
    'nav.howItWorks': 'How It Works',
    'nav.forOwners': 'For Owners',
    'nav.forRenters': 'For Renters',
    'nav.tests': '🧪 Tests',
    'nav.dashboard': 'Dashboard',
    'nav.logOut': 'Log Out',
    'nav.logIn': 'Log In',
    'nav.signUp': 'Sign Up',
    
    // Hero
    'hero.title': 'Rent an Olive Tree.',
    'hero.subtitle': 'Connect with the land, support local growers, and enjoy your very own olive harvest.',
    'hero.findYourTree': 'Find Your Tree',
    'hero.forOwners': 'For Olive Grove Owners',
    
    // Find Your Tree
    'findTree.title': 'Find Your Perfect Tree',
    'findTree.subtitle': 'Search through our collection of beautiful olive groves and find the perfect tree to call your own.',
    'findTree.searchGroves': 'Search Groves',
    'findTree.findPerfectGrove': 'Find Your Perfect Grove',
    'findTree.exploreDescription': 'Click the button above to explore our collection of olive groves and find the perfect tree for you.',
    
    // How It Works
    'howItWorks.title': 'How OliveFriends Works',
    'howItWorks.subtitle': 'A simple path to your personal olive harvest.',
    'howItWorks.step1.title': '1. Choose Your Grove',
    'howItWorks.step1.description': 'Explore beautiful, family-owned olive groves and select the one that speaks to you.',
    'howItWorks.step2.title': '2. Rent Your Tree',
    'howItWorks.step2.description': 'Rent your very own olive tree for a year. You\'ll get updates and can even visit your tree!',
    'howItWorks.step3.title': '3. Enjoy Your Harvest',
    'howItWorks.step3.description': 'Receive the olives or freshly pressed oil from your tree, delivered right to your doorstep.',
    
    // Featured Groves
    'featuredGroves.title': 'Featured Olive Groves',
    'featuredGroves.subtitle': 'Discover the heart and soul behind your olive oil.',
    'featuredGroves.ownedBy': 'Owned by:',
    'featuredGroves.loginToView': 'Login to view contact details',
    'featuredGroves.contactVia': 'Contact via grove owner page',
    'featuredGroves.exploreGrove': 'Explore Grove',
    'featuredGroves.loginToExplore': 'Login to Explore',
    'featuredGroves.noGroves': 'No groves available at the moment.',
    'featuredGroves.error': 'Unable to load groves at the moment. Please try again later.',
    'featuredGroves.findYourTree': 'Find Your Tree',
    
    // Testimonials
    'testimonials.title': 'From the OliveFriends Family',
    
    // Value Proposition
    'valueProposition.forRenter.title': 'For the Renter',
    'valueProposition.forRenter.description': 'Experience a true connection to your food. Adopt an olive tree and receive its unique harvest, knowing exactly where it comes from and the care it received.',
    'valueProposition.forRenter.feature1': 'Follow your tree\'s journey from flower to fruit.',
    'valueProposition.forRenter.feature2': 'Receive 100% of your tree\'s olive or oil production.',
    'valueProposition.forRenter.feature3': 'Visit your grove and participate in the harvest.',
    'valueProposition.forRenter.button': 'Find My Tree',
    'valueProposition.forOwner.title': 'For the Grove Owner',
    'valueProposition.forOwner.description': 'Share your passion with the world. Gain a stable, predictable income and build a community around your grove, all while continuing your family\'s legacy.',
    'valueProposition.forOwner.feature1': 'Create a new revenue stream for your grove.',
    'valueProposition.forOwner.feature2': 'Connect directly with people who love your products.',
    'valueProposition.forOwner.feature3': 'Share your story and preserve your heritage.',
    'valueProposition.forOwner.button': 'List Your Olive Grove',
    
    // Common
    'common.backToHome': 'Back to Home',
    'common.backToMainPage': 'Back to Main Page',
    'common.welcome': 'Welcome to OliveFriends',
    'common.welcomeDescription': 'This is a demo dashboard. Connect with olive groves worldwide and discover the joy of olive tree adoption.',
    'common.loginRequired': 'Login Required',
    'common.loginRequiredDescription': 'Please log in to view owner contact information including email and phone number.',
    'common.login': 'Login',
    'common.loggedOutSuccessfully': 'Logged out successfully',
    
    // Contact & Forms
    'contact.title': 'Contact Us',
    'contact.description': 'Have a question or want to get in touch? Fill out the form below or email us at',
    'contact.name': 'Name',
    'contact.email': 'Email',
    'contact.subject': 'Subject',
    'contact.message': 'Message',
    'contact.yourName': 'Your Name',
    'contact.yourEmail': 'your@email.com',
    'contact.questionAbout': 'Question about...',
    'contact.yourMessage': 'Your message...',
    'contact.sendMessage': 'Send Message',
    'contact.messageSent': 'Message sent!',
    'contact.messageSentDescription': 'Thank you for contacting us. We will get back to you shortly.',
    
    // Grove Details
    'groveDetails.groveInformation': 'Grove Information',
    'groveDetails.description': 'Description',
    'groveDetails.trees': 'Trees',
    'groveDetails.location': 'Location',
    'groveDetails.estimatedHarvest': 'Estimated Harvest',
    'groveDetails.photos': 'Photos',
    'groveDetails.ownerContact': 'Owner Contact Information',
    'groveDetails.name': 'Name',
    'groveDetails.phone': 'Phone',
    'groveDetails.company': 'Company',
    'groveDetails.address': 'Address',
  },
  es: {
    // Header
    'nav.howItWorks': 'Cómo Funciona',
    'nav.forOwners': 'Para Propietarios',
    'nav.forRenters': 'Para Arrendatarios',
    'nav.tests': '🧪 Pruebas',
    'nav.dashboard': 'Panel',
    'nav.logOut': 'Cerrar Sesión',
    'nav.logIn': 'Iniciar Sesión',
    'nav.signUp': 'Registrarse',
    
    // Hero
    'hero.title': 'Alquila un Olivo.',
    'hero.subtitle': 'Conéctate con la tierra, apoya a los productores locales y disfruta de tu propia cosecha de aceitunas.',
    'hero.findYourTree': 'Encuentra Tu Árbol',
    'hero.forOwners': 'Para Propietarios de Olivares',
    
    // Find Your Tree
    'findTree.title': 'Encuentra Tu Árbol Perfecto',
    'findTree.subtitle': 'Busca en nuestra colección de hermosos olivares y encuentra el árbol perfecto para ti.',
    'findTree.searchGroves': 'Buscar Olivares',
    'findTree.findPerfectGrove': 'Encuentra Tu Olivar Perfecto',
    'findTree.exploreDescription': 'Haz clic en el botón de arriba para explorar nuestra colección de olivares y encontrar el árbol perfecto para ti.',
    
    // How It Works
    'howItWorks.title': 'Cómo Funciona OliveFriends',
    'howItWorks.subtitle': 'Un camino simple hacia tu cosecha personal de aceitunas.',
    'howItWorks.step1.title': '1. Elige Tu Olivar',
    'howItWorks.step1.description': 'Explora hermosos olivares familiares y selecciona el que te inspire.',
    'howItWorks.step2.title': '2. Alquila Tu Árbol',
    'howItWorks.step2.description': 'Alquila tu propio olivo por un año. ¡Recibirás actualizaciones e incluso podrás visitar tu árbol!',
    'howItWorks.step3.title': '3. Disfruta Tu Cosecha',
    'howItWorks.step3.description': 'Recibe las aceitunas o el aceite recién prensado de tu árbol, entregado directamente a tu puerta.',
    
    // Featured Groves
    'featuredGroves.title': 'Olivares Destacados',
    'featuredGroves.subtitle': 'Descubre el corazón y el alma detrás de tu aceite de oliva.',
    'featuredGroves.ownedBy': 'Propiedad de:',
    'featuredGroves.loginToView': 'Inicia sesión para ver detalles de contacto',
    'featuredGroves.contactVia': 'Contactar a través de la página del propietario',
    'featuredGroves.exploreGrove': 'Explorar Olivar',
    'featuredGroves.loginToExplore': 'Iniciar Sesión para Explorar',
    'featuredGroves.noGroves': 'No hay olivares disponibles en este momento.',
    'featuredGroves.error': 'No se pueden cargar los olivares en este momento. Inténtalo de nuevo más tarde.',
    'featuredGroves.findYourTree': 'Encuentra Tu Árbol',
    
    // Testimonials
    'testimonials.title': 'De la Familia OliveFriends',
    
    // Value Proposition
    'valueProposition.forRenter.title': 'Para el Arrendatario',
    'valueProposition.forRenter.description': 'Experimenta una verdadera conexión con tu comida. Adopta un olivo y recibe su cosecha única, sabiendo exactamente de dónde viene y el cuidado que recibió.',
    'valueProposition.forRenter.feature1': 'Sigue el viaje de tu árbol desde la flor hasta el fruto.',
    'valueProposition.forRenter.feature2': 'Recibe el 100% de la producción de aceitunas o aceite de tu árbol.',
    'valueProposition.forRenter.feature3': 'Visita tu olivar y participa en la cosecha.',
    'valueProposition.forRenter.button': 'Encuentra Mi Árbol',
    'valueProposition.forOwner.title': 'Para el Propietario del Olivar',
    'valueProposition.forOwner.description': 'Comparte tu pasión con el mundo. Obtén ingresos estables y predecibles y construye una comunidad alrededor de tu olivar, todo mientras continúas el legado de tu familia.',
    'valueProposition.forOwner.feature1': 'Crea una nueva fuente de ingresos para tu olivar.',
    'valueProposition.forOwner.feature2': 'Conéctate directamente con personas que aman tus productos.',
    'valueProposition.forOwner.feature3': 'Comparte tu historia y preserva tu herencia.',
    'valueProposition.forOwner.button': 'Listar Tu Olivar',
    
    // Common
    'common.backToHome': 'Volver al Inicio',
    'common.backToMainPage': 'Volver a la Página Principal',
    'common.welcome': 'Bienvenido a OliveFriends',
    'common.welcomeDescription': 'Este es un panel de demostración. Conéctate con olivares de todo el mundo y descubre la alegría de la adopción de árboles de olivo.',
    'common.loginRequired': 'Inicio de Sesión Requerido',
    'common.loginRequiredDescription': 'Por favor inicia sesión para ver la información de contacto del propietario incluyendo correo electrónico y número de teléfono.',
    'common.login': 'Iniciar Sesión',
    'common.loggedOutSuccessfully': 'Sesión cerrada exitosamente',
    
    // Contact & Forms
    'contact.title': 'Contáctanos',
    'contact.description': '¿Tienes una pregunta o quieres ponerte en contacto? Completa el formulario a continuación o envíanos un correo a',
    'contact.name': 'Nombre',
    'contact.email': 'Correo Electrónico',
    'contact.subject': 'Asunto',
    'contact.message': 'Mensaje',
    'contact.yourName': 'Tu Nombre',
    'contact.yourEmail': 'tu@email.com',
    'contact.questionAbout': 'Pregunta sobre...',
    'contact.yourMessage': 'Tu mensaje...',
    'contact.sendMessage': 'Enviar Mensaje',
    'contact.messageSent': '¡Mensaje enviado!',
    'contact.messageSentDescription': 'Gracias por contactarnos. Te responderemos pronto.',
    
    // Grove Details
    'groveDetails.groveInformation': 'Información del Olivar',
    'groveDetails.description': 'Descripción',
    'groveDetails.trees': 'Árboles',
    'groveDetails.location': 'Ubicación',
    'groveDetails.estimatedHarvest': 'Cosecha Estimada',
    'groveDetails.photos': 'Fotos',
    'groveDetails.ownerContact': 'Información de Contacto del Propietario',
    'groveDetails.name': 'Nombre',
    'groveDetails.phone': 'Teléfono',
    'groveDetails.company': 'Empresa',
    'groveDetails.address': 'Dirección',
  },
  it: {
    // Header
    'nav.howItWorks': 'Come Funziona',
    'nav.forOwners': 'Per Proprietari',
    'nav.forRenters': 'Per Affittuari',
    'nav.tests': '🧪 Test',
    'nav.dashboard': 'Dashboard',
    'nav.logOut': 'Disconnetti',
    'nav.logIn': 'Accedi',
    'nav.signUp': 'Registrati',
    
    // Hero
    'hero.title': 'Affitta un Ulivo.',
    'hero.subtitle': 'Connettiti con la terra, sostieni i coltivatori locali e goditi il tuo raccolto di olive.',
    'hero.findYourTree': 'Trova il Tuo Albero',
    'hero.forOwners': 'Per Proprietari di Uliveti',
    
    // Find Your Tree
    'findTree.title': 'Trova il Tuo Albero Perfetto',
    'findTree.subtitle': 'Cerca nella nostra collezione di bellissimi uliveti e trova l\'albero perfetto per te.',
    'findTree.searchGroves': 'Cerca Uliveti',
    'findTree.findPerfectGrove': 'Trova il Tuo Uliveto Perfetto',
    'findTree.exploreDescription': 'Clicca il pulsante sopra per esplorare la nostra collezione di uliveti e trovare l\'albero perfetto per te.',
    
    // How It Works
    'howItWorks.title': 'Come Funziona OliveFriends',
    'howItWorks.subtitle': 'Un percorso semplice verso il tuo raccolto personale di olive.',
    'howItWorks.step1.title': '1. Scegli il Tuo Uliveto',
    'howItWorks.step1.description': 'Esplora bellissimi uliveti di famiglia e seleziona quello che ti ispira.',
    'howItWorks.step2.title': '2. Affitta il Tuo Albero',
    'howItWorks.step2.description': 'Affitta il tuo ulivo per un anno. Riceverai aggiornamenti e potrai persino visitare il tuo albero!',
    'howItWorks.step3.title': '3. Goditi il Tuo Raccolto',
    'howItWorks.step3.description': 'Ricevi le olive o l\'olio appena spremuto dal tuo albero, consegnato direttamente a casa tua.',
    
    // Featured Groves
    'featuredGroves.title': 'Uliveti in Evidenza',
    'featuredGroves.subtitle': 'Scopri il cuore e l\'anima dietro il tuo olio d\'oliva.',
    'featuredGroves.ownedBy': 'Di proprietà di:',
    'featuredGroves.loginToView': 'Accedi per vedere i dettagli di contatto',
    'featuredGroves.contactVia': 'Contatta tramite la pagina del proprietario',
    'featuredGroves.exploreGrove': 'Esplora Uliveto',
    'featuredGroves.loginToExplore': 'Accedi per Esplorare',
    'featuredGroves.noGroves': 'Nessun uliveto disponibile al momento.',
    'featuredGroves.error': 'Impossibile caricare gli uliveti al momento. Riprova più tardi.',
    'featuredGroves.findYourTree': 'Trova il Tuo Albero',
    
    // Testimonials
    'testimonials.title': 'Dalla Famiglia OliveFriends',
    
    // Value Proposition
    'valueProposition.forRenter.title': 'Per l\'Affittuario',
    'valueProposition.forRenter.description': 'Sperimenta una vera connessione con il tuo cibo. Adotta un ulivo e ricevi il suo raccolto unico, sapendo esattamente da dove viene e le cure che ha ricevuto.',
    'valueProposition.forRenter.feature1': 'Segui il viaggio del tuo albero dal fiore al frutto.',
    'valueProposition.forRenter.feature2': 'Ricevi il 100% della produzione di olive o olio del tuo albero.',
    'valueProposition.forRenter.feature3': 'Visita il tuo uliveto e partecipa al raccolto.',
    'valueProposition.forRenter.button': 'Trova il Mio Albero',
    'valueProposition.forOwner.title': 'Per il Proprietario dell\'Uliveto',
    'valueProposition.forOwner.description': 'Condividi la tua passione con il mondo. Ottieni un reddito stabile e prevedibile e costruisci una comunità attorno al tuo uliveto, continuando l\'eredità della tua famiglia.',
    'valueProposition.forOwner.feature1': 'Crea una nuova fonte di reddito per il tuo uliveto.',
    'valueProposition.forOwner.feature2': 'Collegati direttamente con persone che amano i tuoi prodotti.',
    'valueProposition.forOwner.feature3': 'Condividi la tua storia e preserva la tua eredità.',
    'valueProposition.forOwner.button': 'Elenca il Tuo Uliveto',
    
    // Common
    'common.backToHome': 'Torna alla Home',
    'common.backToMainPage': 'Torna alla Pagina Principale',
    'common.welcome': 'Benvenuto in OliveFriends',
    'common.welcomeDescription': 'Questa è una dashboard demo. Connettiti con uliveti in tutto il mondo e scopri la gioia dell\'adozione di ulivi.',
    'common.loginRequired': 'Accesso Richiesto',
    'common.loginRequiredDescription': 'Per favore accedi per vedere le informazioni di contatto del proprietario inclusi email e numero di telefono.',
    'common.login': 'Accedi',
    'common.loggedOutSuccessfully': 'Disconnesso con successo',
    
    // Contact & Forms
    'contact.title': 'Contattaci',
    'contact.description': 'Hai una domanda o vuoi metterti in contatto? Compila il form qui sotto o inviaci una email a',
    'contact.name': 'Nome',
    'contact.email': 'Email',
    'contact.subject': 'Oggetto',
    'contact.message': 'Messaggio',
    'contact.yourName': 'Il Tuo Nome',
    'contact.yourEmail': 'tua@email.com',
    'contact.questionAbout': 'Domanda su...',
    'contact.yourMessage': 'Il tuo messaggio...',
    'contact.sendMessage': 'Invia Messaggio',
    'contact.messageSent': 'Messaggio inviato!',
    'contact.messageSentDescription': 'Grazie per averci contattato. Ti risponderemo presto.',
    
    // Grove Details
    'groveDetails.groveInformation': 'Informazioni Uliveto',
    'groveDetails.description': 'Descrizione',
    'groveDetails.trees': 'Alberi',
    'groveDetails.location': 'Posizione',
    'groveDetails.estimatedHarvest': 'Raccolto Stimato',
    'groveDetails.photos': 'Foto',
    'groveDetails.ownerContact': 'Informazioni di Contatto Proprietario',
    'groveDetails.name': 'Nome',
    'groveDetails.phone': 'Telefono',
    'groveDetails.company': 'Azienda',
    'groveDetails.address': 'Indirizzo',
  },
  pt: {
    // Header
    'nav.howItWorks': 'Como Funciona',
    'nav.forOwners': 'Para Proprietários',
    'nav.forRenters': 'Para Inquilinos',
    'nav.tests': '🧪 Testes',
    'nav.dashboard': 'Painel',
    'nav.logOut': 'Sair',
    'nav.logIn': 'Entrar',
    'nav.signUp': 'Registar',
    
    // Hero
    'hero.title': 'Alugue uma Oliveira.',
    'hero.subtitle': 'Conecte-se com a terra, apoie produtores locais e desfrute da sua própria colheita de azeitonas.',
    'hero.findYourTree': 'Encontre a Sua Árvore',
    'hero.forOwners': 'Para Proprietários de Olivais',
    
    // Find Your Tree
    'findTree.title': 'Encontre a Sua Árvore Perfeita',
    'findTree.subtitle': 'Pesquise na nossa coleção de belos olivais e encontre a árvore perfeita para si.',
    'findTree.searchGroves': 'Pesquisar Olivais',
    'findTree.findPerfectGrove': 'Encontre o Seu Olival Perfeito',
    'findTree.exploreDescription': 'Clique no botão acima para explorar a nossa coleção de olivais e encontrar a árvore perfeita para si.',
    
    // How It Works
    'howItWorks.title': 'Como Funciona o OliveFriends',
    'howItWorks.subtitle': 'Um caminho simples para a sua colheita pessoal de azeitonas.',
    'howItWorks.step1.title': '1. Escolha o Seu Olival',
    'howItWorks.step1.description': 'Explore belos olivais familiares e selecione aquele que lhe fala ao coração.',
    'howItWorks.step2.title': '2. Alugue a Sua Árvore',
    'howItWorks.step2.description': 'Alugue a sua própria oliveira por um ano. Receberá atualizações e pode até visitar a sua árvore!',
    'howItWorks.step3.title': '3. Desfrute da Sua Colheita',
    'howItWorks.step3.description': 'Receba as azeitonas ou azeite recém-prensado da sua árvore, entregue diretamente à sua porta.',
    
    // Featured Groves
    'featuredGroves.title': 'Olivais em Destaque',
    'featuredGroves.subtitle': 'Descubra o coração e a alma por trás do seu azeite.',
    'featuredGroves.ownedBy': 'Propriedade de:',
    'featuredGroves.loginToView': 'Entre para ver detalhes de contacto',
    'featuredGroves.contactVia': 'Contactar através da página do proprietário',
    'featuredGroves.exploreGrove': 'Explorar Olival',
    'featuredGroves.loginToExplore': 'Entrar para Explorar',
    'featuredGroves.noGroves': 'Nenhum olival disponível no momento.',
    'featuredGroves.error': 'Não foi possível carregar os olivais no momento. Tente novamente mais tarde.',
    'featuredGroves.findYourTree': 'Encontre a Sua Árvore',
    
    // Testimonials
    'testimonials.title': 'Da Família OliveFriends',
    
    // Value Proposition
    'valueProposition.forRenter.title': 'Para o Inquilino',
    'valueProposition.forRenter.description': 'Experimente uma verdadeira conexão com a sua comida. Adote uma oliveira e receba a sua colheita única, sabendo exatamente de onde vem e o cuidado que recebeu.',
    'valueProposition.forRenter.feature1': 'Siga a jornada da sua árvore da flor ao fruto.',
    'valueProposition.forRenter.feature2': 'Receba 100% da produção de azeitonas ou azeite da sua árvore.',
    'valueProposition.forRenter.feature3': 'Visite o seu olival e participe na colheita.',
    'valueProposition.forRenter.button': 'Encontrar a Minha Árvore',
    'valueProposition.forOwner.title': 'Para o Proprietário do Olival',
    'valueProposition.forOwner.description': 'Partilhe a sua paixão com o mundo. Obtenha um rendimento estável e previsível e construa uma comunidade em torno do seu olival, continuando o legado da sua família.',
    'valueProposition.forOwner.feature1': 'Crie uma nova fonte de rendimento para o seu olival.',
    'valueProposition.forOwner.feature2': 'Conecte-se diretamente com pessoas que amam os seus produtos.',
    'valueProposition.forOwner.feature3': 'Partilhe a sua história e preserve a sua herança.',
    'valueProposition.forOwner.button': 'Listar o Seu Olival',
    
    // Common
    'common.backToHome': 'Voltar ao Início',
    'common.backToMainPage': 'Voltar à Página Principal',
    'common.welcome': 'Bem-vindo ao OliveFriends',
    'common.welcomeDescription': 'Este é um painel de demonstração. Conecte-se com olivais em todo o mundo e descubra a alegria da adoção de oliveiras.',
    'common.loginRequired': 'Login Necessário',
    'common.loginRequiredDescription': 'Por favor faça login para ver informações de contacto do proprietário incluindo email e número de telefone.',
    'common.login': 'Entrar',
    'common.loggedOutSuccessfully': 'Sessão terminada com sucesso',
    
    // Contact & Forms
    'contact.title': 'Contacte-nos',
    'contact.description': 'Tem uma pergunta ou quer entrar em contacto? Preencha o formulário abaixo ou envie-nos um email para',
    'contact.name': 'Nome',
    'contact.email': 'Email',
    'contact.subject': 'Assunto',
    'contact.message': 'Mensagem',
    'contact.yourName': 'O Seu Nome',
    'contact.yourEmail': 'seu@email.com',
    'contact.questionAbout': 'Pergunta sobre...',
    'contact.yourMessage': 'A sua mensagem...',
    'contact.sendMessage': 'Enviar Mensagem',
    'contact.messageSent': 'Mensagem enviada!',
    'contact.messageSentDescription': 'Obrigado por nos contactar. Responderemos em breve.',
    
    // Grove Details
    'groveDetails.groveInformation': 'Informações do Olival',
    'groveDetails.description': 'Descrição',
    'groveDetails.trees': 'Árvores',
    'groveDetails.location': 'Localização',
    'groveDetails.estimatedHarvest': 'Colheita Estimada',
    'groveDetails.photos': 'Fotos',
    'groveDetails.ownerContact': 'Informações de Contacto do Proprietário',
    'groveDetails.name': 'Nome',
    'groveDetails.phone': 'Telefone',
    'groveDetails.company': 'Empresa',
    'groveDetails.address': 'Morada',
  },
  el: {
    // Header
    'nav.howItWorks': 'Πώς Λειτουργεί',
    'nav.forOwners': 'Για Ιδιοκτήτες',
    'nav.forRenters': 'Για Μισθωτές',
    'nav.tests': '🧪 Δοκιμές',
    'nav.dashboard': 'Πίνακας Ελέγχου',
    'nav.logOut': 'Αποσύνδεση',
    'nav.logIn': 'Σύνδεση',
    'nav.signUp': 'Εγγραφή',
    
    // Hero
    'hero.title': 'Νοικιάστε μια Ελιά.',
    'hero.subtitle': 'Συνδεθείτε με τη γη, υποστηρίξτε τους τοπικούς παραγωγούς και απολαύστε τη δική σας συγκομιδή ελιών.',
    'hero.findYourTree': 'Βρείτε το Δέντρο σας',
    'hero.forOwners': 'Για Ιδιοκτήτες Ελαιώνων',
    
    // Find Your Tree
    'findTree.title': 'Βρείτε το Τέλειο Δέντρο σας',
    'findTree.subtitle': 'Αναζητήστε στη συλλογή μας από όμορφους ελαιώνες και βρείτε το τέλειο δέντρο για εσάς.',
    'findTree.searchGroves': 'Αναζήτηση Ελαιώνων',
    'findTree.findPerfectGrove': 'Βρείτε τον Τέλειο Ελαιώνα σας',
    'findTree.exploreDescription': 'Κάντε κλικ στο κουμπί παραπάνω για να εξερευνήσετε τη συλλογή μας από ελαιώνες και να βρείτε το τέλειο δέντρο για εσάς.',
    
    // How It Works
    'howItWorks.title': 'Πώς Λειτουργεί το OliveFriends',
    'howItWorks.subtitle': 'Ένας απλός δρόμος προς την προσωπική σας συγκομιδή ελιών.',
    'howItWorks.step1.title': '1. Επιλέξτε τον Ελαιώνα σας',
    'howItWorks.step1.description': 'Εξερευνήστε όμορφους οικογενειακούς ελαιώνες και επιλέξτε αυτόν που σας εμπνέει.',
    'howItWorks.step2.title': '2. Νοικιάστε το Δέντρο σας',
    'howItWorks.step2.description': 'Νοικιάστε τη δική σας ελιά για έναν χρόνο. Θα λαμβάνετε ενημερώσεις και μπορείτε ακόμα να επισκεφτείτε το δέντρο σας!',
    'howItWorks.step3.title': '3. Απολαύστε τη Συγκομιδή σας',
    'howItWorks.step3.description': 'Λάβετε τις ελιές ή το φρεσκοπιεσμένο λάδι από το δέντρο σας, παραδομένο κατευθείαν στην πόρτα σας.',
    
    // Featured Groves
    'featuredGroves.title': 'Επιλεγμένοι Ελαιώνες',
    'featuredGroves.subtitle': 'Ανακαλύψτε την καρδιά και την ψυχή πίσω από το ελαιόλαδό σας.',
    'featuredGroves.ownedBy': 'Ιδιοκτησία του:',
    'featuredGroves.loginToView': 'Συνδεθείτε για να δείτε στοιχεία επικοινωνίας',
    'featuredGroves.contactVia': 'Επικοινωνία μέσω της σελίδας του ιδιοκτήτη',
    'featuredGroves.exploreGrove': 'Εξερευνήστε τον Ελαιώνα',
    'featuredGroves.loginToExplore': 'Συνδεθείτε για Εξερεύνηση',
    'featuredGroves.noGroves': 'Δεν υπάρχουν διαθέσιμοι ελαιώνες αυτή τη στιγμή.',
    'featuredGroves.error': 'Αδυναμία φόρτωσης ελαιώνων αυτή τη στιγμή. Δοκιμάστε ξανά αργότερα.',
    'featuredGroves.findYourTree': 'Βρείτε το Δέντρο σας',
    
    // Testimonials
    'testimonials.title': 'Από την Οικογένεια OliveFriends',
    
    // Value Proposition
    'valueProposition.forRenter.title': 'Για τον Μισθωτή',
    'valueProposition.forRenter.description': 'Ζήστε μια αληθινή σύνδεση με το φαγητό σας. Υιοθετήστε μια ελιά και λάβετε τη μοναδική της συγκομιδή, γνωρίζοντας ακριβώς από πού προέρχεται και τη φροντίδα που έλαβε.',
    'valueProposition.forRenter.feature1': 'Ακολουθήστε το ταξίδι του δέντρου σας από το άνθος στον καρπό.',
    'valueProposition.forRenter.feature2': 'Λάβετε το 100% της παραγωγής ελιών ή λαδιού του δέντρου σας.',
    'valueProposition.forRenter.feature3': 'Επισκεφτείτε τον ελαιώνα σας και συμμετάσχετε στη συγκομιδή.',
    'valueProposition.forRenter.button': 'Βρείτε το Δέντρο μου',
    'valueProposition.forOwner.title': 'Για τον Ιδιοκτήτη Ελαιώνα',
    'valueProposition.forOwner.description': 'Μοιραστείτε το πάθος σας με τον κόσμο. Αποκτήστε σταθερό, προβλέψιμο εισόδημα και χτίστε μια κοινότητα γύρω από τον ελαιώνα σας, συνεχίζοντας την οικογενειακή σας κληρονομιά.',
    'valueProposition.forOwner.feature1': 'Δημιουργήστε μια νέα πηγή εσόδων για τον ελαιώνα σας.',
    'valueProposition.forOwner.feature2': 'Συνδεθείτε απευθείας με ανθρώπους που αγαπούν τα προϊόντα σας.',
    'valueProposition.forOwner.feature3': 'Μοιραστείτε την ιστορία σας και διατηρήστε την κληρονομιά σας.',
    'valueProposition.forOwner.button': 'Καταχωρήστε τον Ελαιώνα σας',
    
    // Common
    'common.backToHome': 'Επιστροφή στην Αρχική',
    'common.backToMainPage': 'Επιστροφή στην Κύρια Σελίδα',
    'common.welcome': 'Καλώς ήρθατε στο OliveFriends',
    'common.welcomeDescription': 'Αυτός είναι ένας πίνακας ελέγχου επίδειξης. Συνδεθείτε με ελαιώνες σε όλο τον κόσμο και ανακαλύψτε τη χαρά της υιοθεσίας ελαιόδεντρων.',
    'common.loginRequired': 'Απαιτείται Σύνδεση',
    'common.loginRequiredDescription': 'Παρακαλώ συνδεθείτε για να δείτε τα στοιχεία επικοινωνίας του ιδιοκτήτη συμπεριλαμβανομένου email και αριθμού τηλεφώνου.',
    'common.login': 'Σύνδεση',
    'common.loggedOutSuccessfully': 'Αποσυνδέθηκε επιτυχώς',
    
    // Contact & Forms
    'contact.title': 'Επικοινωνήστε μαζί μας',
    'contact.description': 'Έχετε μια ερώτηση ή θέλετε να επικοινωνήσετε; Συμπληρώστε τη φόρμα παρακάτω ή στείλτε μας email στο',
    'contact.name': 'Όνομα',
    'contact.email': 'Email',
    'contact.subject': 'Θέμα',
    'contact.message': 'Μήνυμα',
    'contact.yourName': 'Το Όνομά σας',
    'contact.yourEmail': 'το@email.σας',
    'contact.questionAbout': 'Ερώτηση για...',
    'contact.yourMessage': 'Το μήνυμά σας...',
    'contact.sendMessage': 'Αποστολή Μηνύματος',
    'contact.messageSent': 'Το μήνυμα στάλθηκε!',
    'contact.messageSentDescription': 'Ευχαριστούμε που επικοινωνήσατε μαζί μας. Θα σας απαντήσουμε σύντομα.',
    
    // Grove Details
    'groveDetails.groveInformation': 'Πληροφορίες Ελαιώνα',
    'groveDetails.description': 'Περιγραφή',
    'groveDetails.trees': 'Δέντρα',
    'groveDetails.location': 'Τοποθεσία',
    'groveDetails.estimatedHarvest': 'Εκτιμώμενη Συγκομιδή',
    'groveDetails.photos': 'Φωτογραφίες',
    'groveDetails.ownerContact': 'Στοιχεία Επικοινωνίας Ιδιοκτήτη',
    'groveDetails.name': 'Όνομα',
    'groveDetails.phone': 'Τηλέφωνο',
    'groveDetails.company': 'Εταιρεία',
    'groveDetails.address': 'Διεύθυνση',
  },
  de: {
    // Header
    'nav.howItWorks': 'So funktioniert es',
    'nav.forOwners': 'Für Besitzer',
    'nav.forRenters': 'Für Mieter',
    'nav.tests': '🧪 Tests',
    'nav.dashboard': 'Dashboard',
    'nav.logOut': 'Abmelden',
    'nav.logIn': 'Anmelden',
    'nav.signUp': 'Registrieren',
    
    // Hero
    'hero.title': 'Mieten Sie einen Olivenbaum.',
    'hero.subtitle': 'Verbinden Sie sich mit dem Land, unterstützen Sie lokale Erzeuger und genießen Sie Ihre ganz eigene Olivenernte.',
    'hero.findYourTree': 'Ihren Baum finden',
    'hero.forOwners': 'Für Olivenhain-Besitzer',
    
    // Find Your Tree
    'findTree.title': 'Finden Sie Ihren perfekten Baum',
    'findTree.subtitle': 'Durchsuchen Sie unsere Sammlung wunderschöner Olivenhaine und finden Sie den perfekten Baum für sich.',
    'findTree.searchGroves': 'Haine durchsuchen',
    'findTree.findPerfectGrove': 'Finden Sie Ihren perfekten Hain',
    'findTree.exploreDescription': 'Klicken Sie auf die Schaltfläche oben, um unsere Sammlung von Olivenhainen zu erkunden und den perfekten Baum für Sie zu finden.',
    
    // How It Works
    'howItWorks.title': 'So funktioniert OliveFriends',
    'howItWorks.subtitle': 'Ein einfacher Weg zu Ihrer persönlichen Olivenernte.',
    'howItWorks.step1.title': '1. Wählen Sie Ihren Hain',
    'howItWorks.step1.description': 'Erkunden Sie wunderschöne Familien-Olivenhaine und wählen Sie den aus, der Sie anspricht.',
    'howItWorks.step2.title': '2. Mieten Sie Ihren Baum',
    'howItWorks.step2.description': 'Mieten Sie Ihren ganz eigenen Olivenbaum für ein Jahr. Sie erhalten Updates und können sogar Ihren Baum besuchen!',
    'howItWorks.step3.title': '3. Genießen Sie Ihre Ernte',
    'howItWorks.step3.description': 'Erhalten Sie die Oliven oder das frisch gepresste Öl von Ihrem Baum, direkt vor Ihre Haustür geliefert.',
    
    // Featured Groves
    'featuredGroves.title': 'Ausgewählte Olivenhaine',
    'featuredGroves.subtitle': 'Entdecken Sie das Herz und die Seele hinter Ihrem Olivenöl.',
    'featuredGroves.ownedBy': 'Besitzer:',
    'featuredGroves.loginToView': 'Anmelden, um Kontaktdaten zu sehen',
    'featuredGroves.contactVia': 'Kontakt über Besitzer-Seite',
    'featuredGroves.exploreGrove': 'Hain erkunden',
    'featuredGroves.loginToExplore': 'Anmelden zum Erkunden',
    'featuredGroves.noGroves': 'Momentan sind keine Haine verfügbar.',
    'featuredGroves.error': 'Haine können derzeit nicht geladen werden. Bitte versuchen Sie es später erneut.',
    'featuredGroves.findYourTree': 'Ihren Baum finden',
    
    // Testimonials
    'testimonials.title': 'Von der OliveFriends Familie',
    
    // Value Proposition
    'valueProposition.forRenter.title': 'Für den Mieter',
    'valueProposition.forRenter.description': 'Erleben Sie eine wahre Verbindung zu Ihrem Essen. Adoptieren Sie einen Olivenbaum und erhalten Sie seine einzigartige Ernte, wissend genau woher sie kommt und welche Pflege sie erhalten hat.',
    'valueProposition.forRenter.feature1': 'Folgen Sie der Reise Ihres Baumes von der Blüte zur Frucht.',
    'valueProposition.forRenter.feature2': 'Erhalten Sie 100% der Oliven- oder Ölproduktion Ihres Baumes.',
    'valueProposition.forRenter.feature3': 'Besuchen Sie Ihren Hain und nehmen Sie an der Ernte teil.',
    'valueProposition.forRenter.button': 'Meinen Baum finden',
    'valueProposition.forOwner.title': 'Für den Hain-Besitzer',
    'valueProposition.forOwner.description': 'Teilen Sie Ihre Leidenschaft mit der Welt. Erzielen Sie ein stabiles, vorhersagbares Einkommen und bauen Sie eine Gemeinschaft um Ihren Hain auf, während Sie das Erbe Ihrer Familie fortführen.',
    'valueProposition.forOwner.feature1': 'Schaffen Sie eine neue Einnahmequelle für Ihren Hain.',
    'valueProposition.forOwner.feature2': 'Verbinden Sie sich direkt mit Menschen, die Ihre Produkte lieben.',
    'valueProposition.forOwner.feature3': 'Teilen Sie Ihre Geschichte und bewahren Sie Ihr Erbe.',
    'valueProposition.forOwner.button': 'Ihren Olivenhain listen',
    
    // Common
    'common.backToHome': 'Zurück zur Startseite',
    'common.backToMainPage': 'Zurück zur Hauptseite',
    'common.welcome': 'Willkommen bei OliveFriends',
    'common.welcomeDescription': 'Dies ist ein Demo-Dashboard. Verbinden Sie sich mit Olivenhainen weltweit und entdecken Sie die Freude der Olivenbaum-Adoption.',
    'common.loginRequired': 'Anmeldung erforderlich',
    'common.loginRequiredDescription': 'Bitte melden Sie sich an, um Kontaktinformationen des Besitzers einschließlich E-Mail und Telefonnummer zu sehen.',
    'common.login': 'Anmelden',
    'common.loggedOutSuccessfully': 'Erfolgreich abgemeldet',
    
    // Contact & Forms
    'contact.title': 'Kontaktieren Sie uns',
    'contact.description': 'Haben Sie eine Frage oder möchten Sie sich melden? Füllen Sie das Formular unten aus oder senden Sie uns eine E-Mail an',
    'contact.name': 'Name',
    'contact.email': 'E-Mail',
    'contact.subject': 'Betreff',
    'contact.message': 'Nachricht',
    'contact.yourName': 'Ihr Name',
    'contact.yourEmail': 'ihre@email.com',
    'contact.questionAbout': 'Frage zu...',
    'contact.yourMessage': 'Ihre Nachricht...',
    'contact.sendMessage': 'Nachricht senden',
    'contact.messageSent': 'Nachricht gesendet!',
    'contact.messageSentDescription': 'Danke, dass Sie uns kontaktiert haben. Wir werden uns bald bei Ihnen melden.',
    
    // Grove Details
    'groveDetails.groveInformation': 'Hain-Informationen',
    'groveDetails.description': 'Beschreibung',
    'groveDetails.trees': 'Bäume',
    'groveDetails.location': 'Standort',
    'groveDetails.estimatedHarvest': 'Geschätzte Ernte',
    'groveDetails.photos': 'Fotos',
    'groveDetails.ownerContact': 'Besitzer-Kontaktinformationen',
    'groveDetails.name': 'Name',
    'groveDetails.phone': 'Telefon',
    'groveDetails.company': 'Unternehmen',
    'groveDetails.address': 'Adresse',
  },
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    const languageTranslations = translations[language];
    if (!languageTranslations) {
      console.warn(`Language ${language} not found, falling back to English`);
      return translations['en'][key] || key;
    }
    return languageTranslations[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};
