
import { MousePointerClick, HeartHandshake, Package } from 'lucide-react';
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

const HowItWorks = () => {
  const { t } = useLanguage();

  const steps = [
    {
      icon: MousePointerClick,
      title: t('howItWorks.step1.title'),
      description: t('howItWorks.step1.description')
    },
    {
      icon: HeartHandshake,
      title: t('howItWorks.step2.title'),
      description: t('howItWorks.step2.description')
    },
    {
      icon: Package,
      title: t('howItWorks.step3.title'),
      description: t('howItWorks.step3.description')
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-secondary">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-primary">{t('howItWorks.title')}</h2>
          <p className="text-lg text-foreground/80 mt-2">{t('howItWorks.subtitle')}</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 text-center">
          {steps.map(step => (
            <div key={step.title} className="p-6">
              <div className="flex justify-center mb-4">
                <div className="p-4 bg-primary text-primary-foreground rounded-full">
                  <step.icon className="h-10 w-10" />
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-2 text-primary">{step.title}</h3>
              <p className="text-foreground/70">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
