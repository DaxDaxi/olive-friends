
import React from 'react';
import Logo from '@/components/Logo';
import { Github, Twitter, Instagram } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Logo />
            <p className="mt-4 text-sm text-primary-foreground/70">Connecting you to the roots of tradition.</p>
          </div>
          <div className="md:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h4 className="font-bold mb-3">Platform</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/how-it-works" className="text-primary-foreground/70 hover:text-primary-foreground">How it Works</Link></li>
                <li><Link to="/#featured-groves" className="text-primary-foreground/70 hover:text-primary-foreground">Featured Groves</Link></li>
                <li><Link to="/pricing" className="text-primary-foreground/70 hover:text-primary-foreground">Pricing</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-3">Community</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/for-renters" className="text-primary-foreground/70 hover:text-primary-foreground">For Renters</Link></li>
                <li><Link to="/for-owners" className="text-primary-foreground/70 hover:text-primary-foreground">For Owners</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-3">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/about-us" className="text-primary-foreground/70 hover:text-primary-foreground">About Us</Link></li>
                <li><Link to="/contact" className="text-primary-foreground/70 hover:text-primary-foreground">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-3">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/privacy-policy" className="text-primary-foreground/70 hover:text-primary-foreground">Privacy Policy</Link></li>
                <li><Link to="/terms-of-service" className="text-primary-foreground/70 hover:text-primary-foreground">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-primary-foreground/20 flex flex-col sm:flex-row justify-between items-center text-sm">
          <p className="text-primary-foreground/50">&copy; {new Date().getFullYear()} OliveFriends. All rights reserved.</p>
          <div className="flex gap-4 mt-4 sm:mt-0">
            <a href="#" className="text-primary-foreground/70 hover:text-primary-foreground"><Twitter /></a>
            <a href="#" className="text-primary-foreground/70 hover:text-primary-foreground"><Instagram /></a>
            <a href="#" className="text-primary-foreground/70 hover:text-primary-foreground"><Github /></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
