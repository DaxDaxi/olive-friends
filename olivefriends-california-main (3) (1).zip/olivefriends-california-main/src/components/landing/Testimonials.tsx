
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useLanguage } from '@/contexts/LanguageContext';

const testimonials = [
  {
    name: "Maria Rossi",
    role: "Olive Tree Renter",
    avatar: "https://i.pravatar.cc/150?img=1",
    text: "Receiving the olive oil from MY tree was an incredible feeling. The quality is unmatched. My family and I visited the grove during harvest, and it's a memory we'll cherish forever."
  },
  {
    name: "Giuseppe Conti",
    role: "Grove Owner",
    avatar: "https://i.pravatar.cc/150?img=2",
    text: "OliveFriends connected me with wonderful people who truly appreciate our hard work. It's more than just business; it's sharing our passion. The platform has given our small grove a global family."
  },
  {
    name: "Le Pain Quotidien",
    role: "Restaurant Partner",
    avatar: "https://i.pravatar.cc/150?img=3",
    text: "Our customers ask about the olive oil we serve. Being able to tell them the story of our specific trees in Tuscany adds an unparalleled layer of authenticity to our dishes."
  }
];

const Testimonials = () => {
  const { t } = useLanguage();

  return (
    <section id="testimonials" className="py-20 bg-secondary">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-primary">{t('testimonials.title')}</h2>
        </div>
        <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8">
          {testimonials.map(t => (
            <Card key={t.name} className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <p className="text-foreground/80 mb-6 italic">"{t.text}"</p>
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarImage src={t.avatar} alt={t.name} />
                    <AvatarFallback>{t.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-bold text-primary">{t.name}</p>
                    <p className="text-sm text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
