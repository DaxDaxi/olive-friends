
import React from 'react';
import SearchGroves from './SearchGroves';
import { useLanguage } from '@/contexts/LanguageContext';

const FindYourTree = () => {
  const { t } = useLanguage();

  return (
    <section id="find-a-tree" className="py-20 bg-muted/50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">{t('findTree.title')}</h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            {t('findTree.subtitle')}
          </p>
        </div>
        <div className="max-w-4xl mx-auto">
          <SearchGroves />
        </div>
      </div>
    </section>
  );
};

export default FindYourTree;
