
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';

const Pricing = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">Pricing</h1>
          <div className="space-y-4 text-lg text-foreground/80">
            <h2 className="text-2xl font-bold pt-4">For Renters</h2>
            <p>
              The cost of renting an olive tree varies depending on the grove, the age and type of the tree, and its expected yield. Prices are set directly by the grove owners. A typical one-year rental includes:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>The exclusive harvest from your chosen tree.</li>
              <li>Regular updates and photos from the grove.</li>
              <li>A personalized adoption certificate.</li>
              <li>Delivery of your olive oil after the harvest (shipping costs may apply).</li>
            </ul>
            <p>Explore our <Link to="/#featured-groves" className="text-primary hover:underline">featured groves</Link> to see specific pricing for available trees.</p>
            
            <h2 className="text-2xl font-bold pt-8">For Grove Owners</h2>
            <p>
              Listing your grove on OliveFriends is free. We operate on a commission-based model, which means we only make money when you do. We charge a small percentage of each successful tree rental. This commission covers:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Marketing your grove to a global audience.</li>
              <li>Secure payment processing.</li>
              <li>Customer support and platform maintenance.</li>
              <li>Tools to help you manage your rentals and communicate with your patrons.</li>
            </ul>
            <p>We believe in a partnership that is fair and beneficial for our growers. For more details on our commission structure, please <Link to="/contact" className="text-primary hover:underline">contact us</Link>.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Pricing;
