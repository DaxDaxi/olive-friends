
import React from 'react';
import { CardHeader } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';
import Logo from '@/components/Logo';

interface InvoiceHeaderProps {
  invoiceNumber: string;
}

const InvoiceHeader = ({ invoiceNumber }: InvoiceHeaderProps) => {
  return (
    <CardHeader className="text-center border-b">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
          <Logo />
        </div>
        <div className="text-right">
          <h1 className="text-2xl font-bold">MEMBERSHIP INVOICE</h1>
          <p className="text-muted-foreground">Invoice #{invoiceNumber}</p>
        </div>
      </div>
      <div className="flex items-center justify-center mb-8 text-green-600">
        <CheckCircle className="h-6 w-6 mr-2" />
        <span className="font-semibold">Payment Confirmed</span>
      </div>
    </CardHeader>
  );
};

export default InvoiceHeader;
