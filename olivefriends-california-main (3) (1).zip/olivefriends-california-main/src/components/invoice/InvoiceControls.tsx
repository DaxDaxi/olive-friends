
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';

interface InvoiceControlsProps {
  onPrint: () => void;
}

const InvoiceControls = ({ onPrint }: InvoiceControlsProps) => {
  return (
    <div className="mb-6 print:hidden">
      <div className="flex gap-4 justify-center">
        <Button onClick={onPrint} className="flex items-center gap-2">
          <Printer className="h-4 w-4" />
          Print Invoice
        </Button>
        <Link to="/">
          <Button variant="outline">Return to Home</Button>
        </Link>
      </div>
    </div>
  );
};

export default InvoiceControls;
