
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';
import { useLanguage } from '@/contexts/LanguageContext';

const AboutUs = () => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('common.backToHome')}
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">About OliveFriends</h1>
          <div className="space-y-4 text-lg text-foreground/80">
            <p>
              OliveFriends was born from a love of two things: authentic, high-quality olive oil and the stories of the people who produce it. We were tired of the confusing and often misleading olive oil market and wanted to create a direct bridge between passionate growers and conscious consumers.
            </p>
            <p>
              Our mission is simple: to foster a global community around the olive tree. We believe that by creating personal connections, we can help preserve agricultural traditions, promote sustainable farming, and bring a higher quality of product to tables around the world.
            </p>
            <p>
              We are a team of food lovers, tech enthusiasts, and storytellers dedicated to making the world of olive oil more transparent, personal, and delicious.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AboutUs;
