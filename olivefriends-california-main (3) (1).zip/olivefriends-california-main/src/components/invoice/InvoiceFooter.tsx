
import React from 'react';

const InvoiceFooter = () => {
  return (
    <>
      {/* Terms and conditions */}
      <div className="text-sm text-muted-foreground border-t pt-6">
        <h4 className="font-semibold mb-2">Terms & Conditions:</h4>
        <ul className="space-y-1 list-disc list-inside">
          <li>This membership is valid for 12 months from the payment date.</li>
          <li>The included olive tree rental is subject to availability and grove owner terms.</li>
          <li>Membership benefits are non-transferable and non-refundable.</li>
          <li>Additional tree rentals may be purchased separately.</li>
        </ul>
      </div>

      {/* Footer */}
      <div className="text-center mt-8 pt-6 border-t">
        <p className="text-sm text-muted-foreground">
          Thank you for joining the OliveFriends community!
        </p>
        <p className="text-xs text-muted-foreground mt-2">
          For support, contact us at support@olivefriends.com
        </p>
      </div>
    </>
  );
};

export default InvoiceFooter;
