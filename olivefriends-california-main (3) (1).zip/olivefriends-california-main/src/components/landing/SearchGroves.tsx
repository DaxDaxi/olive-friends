
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Trees } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const SearchGroves = () => {
  const { t } = useLanguage();

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <Button asChild className="w-full">
          <a href="https://groves.olive-friends.com" target="_blank" rel="noopener noreferrer">
            <Search className="h-4 w-4" />
            {t('findTree.searchGroves')}
          </a>
        </Button>
      </div>

      <div className="space-y-4">
        <Card>
          <CardContent className="p-6 text-center">
            <Trees className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">{t('findTree.findPerfectGrove')}</h3>
            <p className="text-muted-foreground">
              {t('findTree.exploreDescription')}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SearchGroves;
