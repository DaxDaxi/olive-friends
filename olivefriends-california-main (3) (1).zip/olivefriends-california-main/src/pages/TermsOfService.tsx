
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';

const TermsOfService = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">Terms of Service</h1>
          <div className="space-y-4 text-foreground/80">
            <p><strong>Last Updated: {new Date().toLocaleDateString()}</strong></p>
            <p>Please read these Terms of Service ("Terms") carefully before using the OliveFriends website and services.</p>
            <h2 className="text-2xl font-bold pt-4">Agreement to Terms</h2>
            <p>By accessing or using our services, you agree to be bound by these Terms. If you do not agree to these Terms, you may not use the services.</p>
            <h2 className="text-2xl font-bold pt-4">Services</h2>
            <p>OliveFriends provides a platform for users to rent olive trees ("Renters") from olive grove owners ("Owners"). We are a marketplace and are not responsible for the farming, harvesting, or production of olive products.</p>
            <h2 className="text-2xl font-bold pt-4">User Accounts</h2>
            <p>You must create an account to use certain features of our service. You are responsible for safeguarding your account and for all activities that occur under it.</p>
            <p>This is a placeholder agreement. For a complete understanding, please consult with a legal professional.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default TermsOfService;
