
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';

const EdgeFunctionTests = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Tests</h1>
          
          <Card>
            <CardHeader>
              <CardTitle>Application Tests</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Backend functionality has been removed. This is now a frontend-only application.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default EdgeFunctionTests;
