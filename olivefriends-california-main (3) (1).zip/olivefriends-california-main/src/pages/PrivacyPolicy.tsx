
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';

const PrivacyPolicy = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">Privacy Policy</h1>
          <div className="space-y-4 text-foreground/80">
            <p><strong>Last Updated: {new Date().toLocaleDateString()}</strong></p>
            <p>Your privacy is important to us. This Privacy Policy explains how OliveFriends collects, uses, and discloses information about you.</p>
            <h2 className="text-2xl font-bold pt-4">Information We Collect</h2>
            <p>We collect information you provide directly to us, such as when you create an account, rent a tree, list a grove, or communicate with us. This may include your name, email address, shipping address, and payment information.</p>
            <h2 className="text-2xl font-bold pt-4">How We Use Information</h2>
            <p>We use the information we collect to operate, maintain, and provide the features and functionality of our service, to communicate with you, to process transactions, and for other customer service purposes.</p>
            <h2 className="text-2xl font-bold pt-4">Information Sharing</h2>
            <p>We do not share your personal information with third parties except as described in this policy. We may share information with vendors, consultants, and other service providers who need access to such information to carry out work on our behalf.</p>
            <p>This is a placeholder policy. For a complete understanding, please consult with a legal professional.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default PrivacyPolicy;
