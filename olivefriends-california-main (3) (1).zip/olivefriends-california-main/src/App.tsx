
import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { LanguageProvider } from "@/contexts/LanguageContext";

import Index from "@/pages/Index";
import HowItWorks from "@/pages/HowItWorks";
import ForRenters from "@/pages/ForRenters";
import ForOwners from "@/pages/ForOwners";
import Pricing from "@/pages/Pricing";
import AboutUs from "@/pages/AboutUs";
import Contact from "@/pages/Contact";
import TermsOfService from "@/pages/TermsOfService";
import PrivacyPolicy from "@/pages/PrivacyPolicy";
import MembershipSuccess from "@/pages/MembershipSuccess";
import MembershipInvoice from "@/pages/MembershipInvoice";
import NotFound from "@/pages/NotFound";
import PaymentSuccess from "@/pages/PaymentSuccess";
import GroveOwner from "@/pages/GroveOwner";
import EdgeFunctionTests from "@/pages/EdgeFunctionTests";

// Add test link for development
const isDevelopment = window.location.hostname === 'localhost' || window.location.hostname.includes('lovable.app');

const router = createBrowserRouter([
  {
    path: "/",
    element: <Index />,
  },
  {
    path: "/how-it-works",
    element: <HowItWorks />,
  },
  {
    path: "/for-renters",
    element: <ForRenters />,
  },
  {
    path: "/for-owners",
    element: <ForOwners />,
  },
  {
    path: "/pricing",
    element: <Pricing />,
  },
  {
    path: "/about-us",
    element: <AboutUs />,
  },
  {
    path: "/contact",
    element: <Contact />,
  },
  {
    path: "/terms-of-service",
    element: <TermsOfService />,
  },
  {
    path: "/privacy-policy",
    element: <PrivacyPolicy />,
  },
  {
    path: "/membership-success",
    element: <MembershipSuccess />,
  },
  {
    path: "/membership-invoice",
    element: <MembershipInvoice />,
  },
  {
    path: "/payment-success",
    element: <PaymentSuccess />,
  },
  {
    path: "/grove-owner/:ownerId",
    element: <GroveOwner />,
  },
  ...(isDevelopment ? [{
    path: "/test-functions",
    element: <EdgeFunctionTests />,
  }] : []),
  {
    path: "*",
    element: <NotFound />,
  },
]);

function App() {
  return (
    <React.StrictMode>
      <AuthProvider>
        <LanguageProvider>
          <RouterProvider router={router} />
        </LanguageProvider>
      </AuthProvider>
    </React.StrictMode>
  );
}

export default App;
