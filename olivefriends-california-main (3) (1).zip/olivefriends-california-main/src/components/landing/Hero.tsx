
import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const Hero = () => {
  const { t } = useLanguage();

  return (
    <section className="relative h-[calc(100vh-5rem)] min-h-[500px] flex items-center justify-center text-center text-white">
      <div className="absolute inset-0 bg-black/40 z-10" />
      <img
        src="/lovable-uploads/50657f23-a00c-41cc-b9df-add0bbcfd687.png"
        alt="Olive oil being poured into a glass bowl with olives nearby"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="relative z-20 container px-4">
        <h1 className="text-5xl md:text-7xl font-black mb-4 font-serif text-shadow-lg">
          {t('hero.title')}
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-shadow">
          {t('hero.subtitle')}
        </p>
        <div className="flex justify-center gap-4">
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
            <a href="https://groves.olive-friends.com" target="_blank" rel="noopener noreferrer">
              {t('hero.findYourTree')} <ChevronRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
            <a href="#for-owners">{t('hero.forOwners')}</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
