
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const FeaturedGroves = () => {
  const { t } = useLanguage();

  // Mock data for featured groves
  const mockGroves = [
    {
      id: '1',
      name: 'Sunny Valley Grove',
      latitude: 34.0522,
      longitude: -118.2437,
      tree_count: 50,
      estimated_harvest: '15kg/tree',
      description: 'A beautiful olive grove in Los Angeles with premium Arbequina olives, perfect sun exposure and organic farming practices.',
      picture_urls: [],
      profiles: {
        full_name: 'John Smith',
        company_name: 'Valley Groves Inc.',
        phone_number: '+1-555-0123'
      }
    },
    {
      id: '2',
      name: 'Golden Hills Grove',
      latitude: 37.7749,
      longitude: -122.4194,
      tree_count: 75,
      estimated_harvest: '18kg/tree',
      description: 'Historic olive grove near San Francisco with 100-year-old trees producing exceptional extra virgin olive oil.',
      picture_urls: [],
      profiles: {
        full_name: 'Maria Garcia',
        company_name: 'Golden Hills Estates',
        phone_number: '+1-555-0456'
      }
    },
    {
      id: '3',
      name: 'Coastal Breeze Grove',
      latitude: 32.7157,
      longitude: -117.1611,
      tree_count: 100,
      estimated_harvest: '20kg/tree',
      description: 'Premium coastal grove in San Diego featuring Picual and Frantoio varieties with sustainable irrigation systems.',
      picture_urls: [],
      profiles: {
        full_name: 'David Johnson',
        company_name: 'Coastal Olive Co.',
        phone_number: '+1-555-0789'
      }
    }
  ];

  const handleGroveExplore = () => {
    window.open('https://groves.olive-friends.com', '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="featured-groves" className="py-20">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-primary">{t('featuredGroves.title')}</h2>
          <p className="text-lg text-foreground/80 mt-2">{t('featuredGroves.subtitle')}</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {mockGroves.map(grove => (
            <Card key={grove.id} className="overflow-hidden flex flex-col hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">{grove.name}</CardTitle>
                <CardDescription className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" /> 
                  {grove.latitude.toFixed(2)}, {grove.longitude.toFixed(2)}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                {grove.description && (
                  <p className="text-foreground/70 mb-4">{grove.description}</p>
                )}
                {grove.profiles && (
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      {t('featuredGroves.ownedBy')} {grove.profiles.full_name || grove.profiles.company_name || 'Grove Owner'}
                    </p>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full bg-primary hover:bg-primary/90"
                  onClick={handleGroveExplore}
                >
                  {t('featuredGroves.findYourTree')}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedGroves;
