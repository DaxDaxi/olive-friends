
import Header from "@/components/landing/Header";
import Hero from "@/components/landing/Hero";
import FindYourTree from "@/components/landing/FindYourTree";
import HowItWorks from "@/components/landing/HowItWorks";
import FeaturedGroves from "@/components/landing/FeaturedGroves";
import ValueProposition from "@/components/landing/ValueProposition";
import Testimonials from "@/components/landing/Testimonials";
import Footer from "@/components/landing/Footer";

const Index = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background font-sans">
      <Header />
      <main className="flex-grow">
        <Hero />
        <FindYourTree />
        <HowItWorks />
        <FeaturedGroves />
        <ValueProposition />
        <Testimonials />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
